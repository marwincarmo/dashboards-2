#' Soma
#'
#' Faz a soma de x e y.
#'
#' @param x um n\u00famero
#' @param y um outro n\u00famero
#'
#' @return Um valor num\u00e9rico.
#' @export
soma <- function(x, y) {
  x + y
}
